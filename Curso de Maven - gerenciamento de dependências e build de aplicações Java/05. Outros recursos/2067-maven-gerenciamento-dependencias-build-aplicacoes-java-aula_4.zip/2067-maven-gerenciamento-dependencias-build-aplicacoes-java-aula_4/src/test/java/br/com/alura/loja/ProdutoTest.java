package br.com.alura.loja;

import org.junit.Test;

public class ProdutoTest {

	@Test
	public void test() {
	}

}
