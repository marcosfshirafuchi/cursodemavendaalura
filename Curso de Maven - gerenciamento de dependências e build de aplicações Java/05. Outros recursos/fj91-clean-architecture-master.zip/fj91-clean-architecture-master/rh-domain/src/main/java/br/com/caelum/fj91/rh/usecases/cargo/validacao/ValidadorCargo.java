package br.com.caelum.fj91.rh.usecases.cargo.validacao;

import br.com.caelum.fj91.rh.domain.cargo.Cargo;

public interface ValidadorCargo {
	
	void validar(Cargo cargo);

}
