package br.com.caelum.fj91.rh.usecases.funcionario.validacao.cadastro;

import br.com.caelum.fj91.rh.usecases.funcionario.validacao.ValidadorFuncionario;

public interface ValidadorCadastroFuncionario extends ValidadorFuncionario {

}
