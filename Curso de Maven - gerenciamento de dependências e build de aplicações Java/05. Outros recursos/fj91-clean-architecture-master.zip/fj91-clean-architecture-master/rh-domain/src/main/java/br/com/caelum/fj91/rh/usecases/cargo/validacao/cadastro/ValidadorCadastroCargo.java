package br.com.caelum.fj91.rh.usecases.cargo.validacao.cadastro;

import br.com.caelum.fj91.rh.usecases.cargo.validacao.ValidadorCargo;

public interface ValidadorCadastroCargo extends ValidadorCargo {
	
}
