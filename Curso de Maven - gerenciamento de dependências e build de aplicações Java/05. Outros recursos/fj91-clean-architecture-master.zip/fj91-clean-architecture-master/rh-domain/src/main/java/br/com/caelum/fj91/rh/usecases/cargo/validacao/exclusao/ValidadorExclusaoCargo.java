package br.com.caelum.fj91.rh.usecases.cargo.validacao.exclusao;

import br.com.caelum.fj91.rh.usecases.cargo.validacao.ValidadorCargo;

public interface ValidadorExclusaoCargo extends ValidadorCargo {
	
}
