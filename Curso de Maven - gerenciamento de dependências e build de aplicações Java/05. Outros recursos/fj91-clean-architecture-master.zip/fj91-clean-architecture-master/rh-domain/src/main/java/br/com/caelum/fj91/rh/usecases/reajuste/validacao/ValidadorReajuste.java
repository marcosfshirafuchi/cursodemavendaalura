package br.com.caelum.fj91.rh.usecases.reajuste.validacao;

import br.com.caelum.fj91.rh.domain.reajuste.Reajuste;

public interface ValidadorReajuste {
	
	void validar(Reajuste reajuste);

}
