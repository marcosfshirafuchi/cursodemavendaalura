package br.com.caelum.fj91.rh.usecases.funcionario.validacao;

import br.com.caelum.fj91.rh.domain.funcionario.Funcionario;

public interface ValidadorFuncionario {
	
	void validar(Funcionario funcionario);

}
